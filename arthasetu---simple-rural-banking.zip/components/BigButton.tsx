
import React from 'react';

interface BigButtonProps {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  color?: string;
  fullWidth?: boolean;
}

export const BigButton: React.FC<BigButtonProps> = ({ icon, label, onClick, color = 'bg-white', fullWidth = false }) => {
  return (
    <button
      onClick={onClick}
      className={`${color} ${fullWidth ? 'w-full' : ''} p-6 rounded-2xl shadow-md border-b-4 border-black/10 flex flex-col items-center justify-center gap-3 transition-transform active:scale-95 group`}
    >
      <div className="p-3 rounded-full bg-slate-100 group-active:bg-slate-200 transition-colors">
        {icon}
      </div>
      <span className="font-bold text-lg text-slate-800 text-center leading-tight">
        {label}
      </span>
    </button>
  );
};
