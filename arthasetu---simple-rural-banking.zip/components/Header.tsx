
import React from 'react';
import { Language } from '../types';
import { TEXTS } from '../constants';

interface HeaderProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
}

export const Header: React.FC<HeaderProps> = ({ lang, onLanguageChange }) => {
  const languages: { code: Language; label: string }[] = [
    { code: 'kn', label: 'ಕನ್ನಡ' },
    { code: 'hi', label: 'हिंदी' },
    { code: 'en', label: 'Eng' },
  ];

  return (
    <div className="sticky top-0 z-50 bg-white">
      <header className="border-b border-slate-200 px-4 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center shadow-lg shadow-emerald-200">
            <span className="text-white font-black text-xl">G</span>
          </div>
          <h1 className="text-xl font-black text-slate-900 tracking-tight">{TEXTS[lang].appName}</h1>
        </div>
        
        <div className="flex gap-1">
          {languages.map((l) => (
            <button
              key={l.code}
              onClick={() => onLanguageChange(l.code)}
              className={`px-3 py-1.5 rounded-lg text-sm font-bold transition-all ${
                lang === l.code 
                ? 'bg-emerald-600 text-white shadow-sm' 
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>
      </header>
      <div className="bg-amber-100 px-4 py-1 overflow-hidden whitespace-nowrap">
        <div className="animate-marquee inline-block text-[10px] font-black uppercase text-amber-800 tracking-widest">
           🌾 0% Interest Loans for Small Farmers • ✨ Gold Loan starting at 7% • 🏠 House Repair Loans Available • 🌾 
        </div>
      </div>
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
        .animate-marquee {
          animation: marquee 20s linear infinite;
        }
      `}</style>
    </div>
  );
};
