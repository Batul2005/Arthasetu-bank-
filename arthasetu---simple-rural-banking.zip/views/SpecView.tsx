import React from 'react';
import { ArrowRight, CheckCircle } from 'lucide-react';

interface SpecViewProps {
  onStart: () => void;
}

export const SpecView: React.FC<SpecViewProps> = ({ onStart }) => {
  return (
    <div className="bg-white p-6 max-h-screen overflow-y-auto pb-32">
      <div className="max-w-3xl mx-auto space-y-8">
        <header className="border-b pb-6">
          <h1 className="text-3xl font-black text-emerald-800">ArthaSetu</h1>
          <p className="text-slate-600 mt-2">Design Specs for Low-Tech Indian Rural Users</p>
        </header>

        <section>
          <h2 className="text-xl font-bold text-slate-800 mb-4">1. Empathize (Pain Points)</h2>
          <ul className="space-y-2 text-slate-700">
            <li className="flex gap-2">❌ <span className="font-semibold">Fear of Mistakes:</span> Worried that one wrong tap will lose all their money.</li>
            <li className="flex gap-2">❌ <span className="font-semibold">Language Barrier:</span> Most apps use complex banking English.</li>
            <li className="flex gap-2">❌ <span className="font-semibold">Digital Literacy:</span> Confused by nested menus, icons without labels, and technical terms.</li>
            <li className="flex gap-2">❌ <span className="font-semibold">Small Fonts:</span> Difficulty reading small text on cheap mobile screens.</li>
            <li className="flex gap-2">❌ <span className="font-semibold">Abstract IDs:</span> Complex account numbers are hard to remember and share.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-800 mb-4">2. Define (5 Main Problems)</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <span className="font-bold block mb-1">P1: Confidence</span> Users don't trust their own ability to use an app.
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <span className="font-bold block mb-1">P2: Verification</span> Fear of sending money to the wrong person.
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <span className="font-bold block mb-1">P3: Accessibility</span> UI is often too cluttered for elderly fingers.
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <span className="font-bold block mb-1">P4: Onboarding</span> Signing up feels like a legal exam.
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <span className="font-bold block mb-1">P5: Feedback</span> No clear indication of "What happens next?"
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-xl font-bold text-slate-800 mb-4">3. Ideate (Solutions)</h2>
          <div className="space-y-4">
            <div className="flex gap-4">
              <CheckCircle className="text-emerald-500 flex-shrink-0" />
              <p><span className="font-bold">Voice-First Approach:</span> Every screen has an assistant that speaks in their mother tongue (Kannada, Hindi, English).</p>
            </div>
            <div className="flex gap-4">
              <CheckCircle className="text-emerald-500 flex-shrink-0" />
              <p><span className="font-bold">Human-Friendly IDs:</span> Auto-generated ID (BANK-KA-2026-XXXX) that feels like an Aadhaar number – recognizable and easy to say aloud.</p>
            </div>
            <div className="flex gap-4">
              <CheckCircle className="text-emerald-500 flex-shrink-0" />
              <p><span className="font-bold">Large Interactive Surface:</span> Massive buttons with Icon + Text. No tap targets smaller than 60px.</p>
            </div>
          </div>
        </section>

        <div className="sticky bottom-0 bg-white pt-4 border-t">
          <button 
            onClick={onStart}
            className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold text-xl flex items-center justify-center gap-2 shadow-xl hover:bg-emerald-700 transition-colors"
          >
            Enter App Simulation <ArrowRight />
          </button>
        </div>
      </div>
    </div>
  );
};