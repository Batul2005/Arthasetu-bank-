
import { GoogleGenAI, Modality } from "@google/genai";
import { Language } from "../types";

const API_KEY = process.env.API_KEY || "";

export class AIService {
  static async speak(text: string, lang: Language): Promise<void> {
    console.log(`AI Speaking (${lang}): ${text}`);
    
    // Fallback for simulation fluidity or if API key is not configured for high-quality TTS
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.85; // Slow for clarity
    switch(lang) {
      case 'kn': utterance.lang = 'kn-IN'; break;
      case 'hi': utterance.lang = 'hi-IN'; break;
      default: utterance.lang = 'en-IN'; break;
    }
    window.speechSynthesis.speak(utterance);

    // If API Key is available, we could use gemini-2.5-flash-preview-tts here
    // But for a realistic prototype, immediate browser feedback is less laggy
  }

  static async transcribe(blob: Blob, lang: Language): Promise<string> {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    // In actual use, we'd send the audio blob to gemini-2.5-flash-native-audio-preview
    return "Confirm";
  }
}
