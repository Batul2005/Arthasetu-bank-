
import { User, Transaction } from "../types";

const USER_KEY = 'gramin_user';
const TX_KEY = 'gramin_transactions';
const REGISTRY_KEY = 'gramin_global_registry';

export class StorageService {
  static saveUser(user: User) {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    // Add to simulated global registry for cross-lookup
    const registry = this.getRegistry();
    registry[user.id] = user.name;
    localStorage.setItem(REGISTRY_KEY, JSON.stringify(registry));
  }

  static getUser(): User | null {
    const data = localStorage.getItem(USER_KEY);
    return data ? JSON.parse(data) : null;
  }

  static getRegistry(): Record<string, string> {
    const data = localStorage.getItem(REGISTRY_KEY);
    return data ? JSON.parse(data) : {
      "BANK-KA-2026-111222": "Ramesh Kumar",
      "BANK-KA-2026-333444": "Siddappa Gowda",
      "BANK-KA-2026-555666": "Laxmi Bai",
      "BANK-KA-2026-777888": "Gowramma Devi"
    };
  }

  static clear() {
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem(TX_KEY);
  }

  static generateId(): string {
    const year = new Date().getFullYear();
    const random = Math.floor(100000 + Math.random() * 900000);
    return `BANK-KA-${year}-${random}`;
  }

  static getTransactions(): Transaction[] {
    const data = localStorage.getItem(TX_KEY);
    if (data) return JSON.parse(data);
    
    return [
      { id: '1', type: 'credit', amount: 5500, date: '2023-11-20', description: 'Milk Mandi Income', category: 'Income' },
      { id: '2', type: 'debit', amount: 1200, date: '2023-11-22', description: 'Seeds & Fertilizer', category: 'Agri' },
      { id: '3', type: 'debit', amount: 450, date: '2023-11-25', description: 'Grocery Bill', category: 'Food' },
      { id: '4', type: 'credit', amount: 2000, date: '2023-11-28', description: 'Govt Subsidy', category: 'Income' }
    ];
  }

  static saveTransaction(tx: Transaction) {
    const txs = this.getTransactions();
    localStorage.setItem(TX_KEY, JSON.stringify([tx, ...txs].slice(0, 10)));
  }

  static mockSearchName(id: string): string | null {
    const registry = this.getRegistry();
    // Also check local current user specifically to satisfy "when I enter my id" requirement
    const currentUser = this.getUser();
    if (currentUser && currentUser.id === id.toUpperCase()) return currentUser.name;
    
    return registry[id.toUpperCase()] || null;
  }
}
